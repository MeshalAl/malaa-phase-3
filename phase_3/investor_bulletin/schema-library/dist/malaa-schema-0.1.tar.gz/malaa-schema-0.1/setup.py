from setuptools import setup

setup(
    name='malaa-schema',
    version='0.1',
    packages=['malaa_schema'],
    install_requires=[
        'pydantic'
    ]
)
